<?php


function preview($data){
    echo '<pre>'; print_r($data); exit;
}


function upload_img($img,$path){
    if ($img["name"] != '') {
        $file_name = $img['name'];
        $size = $img['size'];
        $file_path = $path;
        list($txt, $ext) = explode(".", $file_name);
        $actual_image_name = time() . substr(str_replace(" ", "_", $txt), 5) . "." . $ext;
        $tmp = $img['tmp_name'];
        if (move_uploaded_file($tmp, $file_path . $actual_image_name)) {
            return $actual_image_name;
        } else {
            return false;
        }
    }
}

function upload_csv($csv, $path){
    if ($csv["name"] != '') {
        $file_name = $csv['name'];
        $size = $csv['size'];
        $file_path = $path;
        list($txt, $ext) = explode(".", $file_name);
        $actual_csv_name = time() . substr(str_replace(" ", "_", $txt), 5) . "." . $ext;
        $tmp = $csv['tmp_name'];
        if (move_uploaded_file($tmp, $file_path . $actual_csv_name)) {
            return $actual_csv_name;
        } else {
            return false;
        }
    }
}



function generate_random_key(){
    return mt_rand(1111,9999);
}


function check_existance($table, $where){
    $ci = & get_instance();
    $res = $ci->db->get_where($table, $where);
    if($res->num_rows() > 0){
        return true;
    }else{
        return false;
    }
}

function ajax_response($status, $data, $message){
    $res = [
        'status' => $status,
        'data' => $data,
        'message' => $message
    ];

    echo json_encode($res);
}


function za_send_email($to, $from,$from_name, $subject, $content){
    $ci = & get_instance();
    $ci->load->library('email');
    
    $config = [
        'protocol' => 'smtp',
        'smtp_host' => SMTP_HOST,
        'smtp_port' => SMTP_PORT,
        'smtp_user' => SMTP_USER,
        'smtp_pass' => SMTP_PASS,
        'mailtype' => 'html'
    ];
    $ci->email->initialize($config);
    $ci->email->to($to);
    $ci->email->from($from, $from_name);
    $ci->email->subject($subject);
    $ci->email->message($content);
    $ci->email->reply_to('support@test.io');
    $res = $ci->email->send();
    //var_dump($res);exit;
    return ($res ? true : false);
}



